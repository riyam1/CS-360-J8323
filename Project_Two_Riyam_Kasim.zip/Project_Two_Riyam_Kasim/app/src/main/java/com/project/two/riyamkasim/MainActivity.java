package com.project.two.riyamkasim;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Function to close the application.
     *
     * @param view
     */
    public void doClose(View view) {
        Toast.makeText(this, "Will be implemented later", Toast.LENGTH_SHORT).show();
    }

    /**
     * Function to login the user
     *
     * @param view
     */
    public void doLogin(View view) {
        // move to Inventory grid
        Intent intent = new Intent(this, Inventory.class);
        startActivity(intent);
    }

    /**
     * Function to move to the Registration Screen
     *
     * @param view
     */
    public void doRegister(View view) {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }


}