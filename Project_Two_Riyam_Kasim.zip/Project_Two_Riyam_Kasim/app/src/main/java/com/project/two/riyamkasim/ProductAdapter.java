package com.project.two.riyamkasim;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;


public class ProductAdapter extends ArrayAdapter<Product> {
    ArrayList<Product> productList;

    public ProductAdapter(@NonNull Context context, ArrayList<Product> productList) {
        super(context, 0, productList);
        this.productList = productList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View listitemView = convertView;
        if (listitemView == null) {
            // Layout Inflater inflates each item to be displayed in GridView.
            listitemView = LayoutInflater.from(getContext()).inflate(R.layout.grid_view_layout, parent, false);
        }

        Product product = productList.get(position);
        TextView txtProductId = (TextView) listitemView.findViewById(R.id.lblProductId);
        TextView txtProductName = (TextView)listitemView.findViewById(R.id.lblProductName);
        TextView txtProductQty = (TextView)listitemView.findViewById(R.id.lblQuantity);

        txtProductId.setText(product.getProductId());
        txtProductName.setText(product.getProductName());
        txtProductQty.setText(String.valueOf(product.getQuantity()));

        ImageView delImage = listitemView.findViewById(R.id.imgDelete);
        delImage.setImageResource(R.drawable.delete);

        return listitemView;
    }

}
