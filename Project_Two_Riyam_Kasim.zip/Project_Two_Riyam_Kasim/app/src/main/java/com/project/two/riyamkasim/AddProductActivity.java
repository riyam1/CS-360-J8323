package com.project.two.riyamkasim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class AddProductActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
    }

    public void doAddProduct(View view) {
        Toast.makeText(this, "Will be implemented later", Toast.LENGTH_SHORT).show();
    }

    public void doBack(View view) {
        Intent intent = new Intent(this, Inventory.class);
        startActivity(intent);
    }
}