package com.project.two.riyamkasim;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.GridView;

import java.util.ArrayList;

public class Inventory extends AppCompatActivity {

    private GridView gridViewProducts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // bind gridview
        ArrayList<Product> productList = new ArrayList<Product>();
        productList.add(new Product("1001", "Mobile Phone", 10));
        productList.add(new Product("1002", "TV", 10));
        productList.add(new Product("1003", "Laptop", 10));

        this.gridViewProducts = findViewById(R.id.gridViewProducts);
        ProductAdapter adapter= new ProductAdapter(this, productList);
        gridViewProducts.setAdapter(adapter);
    }

    public void doAdd(View view) {
        Intent intent = new Intent(this, AddProductActivity.class);
        startActivity(intent);
    }

    public void doLogout(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void setPermissions(View view) {
        if(!checkSMSPermission(Manifest.permission.SEND_SMS)) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        }
    }

    private boolean checkSMSPermission(String sendSms) {
        return ContextCompat.checkSelfPermission(this,sendSms) == PackageManager.PERMISSION_GRANTED;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        grantResults[0] = PackageManager.PERMISSION_GRANTED;
    }
}