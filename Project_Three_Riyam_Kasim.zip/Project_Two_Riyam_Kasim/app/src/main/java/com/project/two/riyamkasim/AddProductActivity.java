package com.project.two.riyamkasim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddProductActivity extends AppCompatActivity {

    // inputs
    private EditText txtProductId;
    private EditText txtProductName;
    private EditText txtQuantity;

    // database handler
    private InventoryDatabase inventoryDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        // database instance
        this.inventoryDatabase = InventoryDatabase.getInstance(this);

        // set references
        this.txtProductId = findViewById(R.id.txtProductId);
        this.txtProductName = findViewById(R.id.txtProductName);
        this.txtQuantity = findViewById(R.id.txtQuantity);

        // disable product id
        this.txtProductId.setKeyListener(null);
        this.txtProductId.setEnabled(false);
    }

    /**
     * Function to add new product
     *
     * @param view
     */
    public void doAddProduct(View view) {

        try {
            // parse values
            String productName = this.txtProductName.getText().toString();
            int quantity = Integer.parseInt(this.txtQuantity.getText().toString());

            if(productName.length() <= 0) {
                Toast.makeText(this, "Please provide product name", Toast.LENGTH_SHORT).show();
                return;
            }

            Product product = new Product();
            product.setProductName(productName);
            product.setQuantity(quantity);

            // insert product
            this.inventoryDatabase.inventoryDao().insertProduct(product);
            Toast.makeText(this, "Product has been saved", Toast.LENGTH_SHORT).show();

            // clear inputs
            this.txtProductName.setText("");
            this.txtQuantity.setText("");
        } catch(Exception e) {
            Toast.makeText(this, "Something Wrong Happened", Toast.LENGTH_SHORT).show();
        }
    }

    public void doBack(View view) {
        Intent intent = new Intent(this, Inventory.class);
        startActivity(intent);
    }
}