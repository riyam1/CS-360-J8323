package com.project.two.riyamkasim;

import android.content.Context;

import androidx.room.Room;
import androidx.room.RoomDatabase;

@androidx.room.Database(entities = {Member.class, Product.class}, version=1)

public abstract class InventoryDatabase extends RoomDatabase {

    public abstract InventoryDao inventoryDao();
    private static InventoryDatabase instance ;

    /**
     * Function to instantiate the instance of Inventory Database handler class
     *
     * @param context of this application
     * @return the InventoryDatabase instance
     */
    public static InventoryDatabase getInstance(Context context){
        if(instance == null){
            instance = Room.databaseBuilder(context, InventoryDatabase.class,
                            "InventoryDB")
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }

        return instance;
    }
}
