package com.project.two.riyamkasim;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;


public class ProductAdapter extends ArrayAdapter<Product> {
    List<Product> productList;

    public ProductAdapter(@NonNull Context context, List<Product> productList) {
        super(context, 0, productList);
        this.productList = productList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View listitemView = convertView;
        if (listitemView == null) {
            // Layout Inflater inflates each item to be displayed in GridView.
            listitemView = LayoutInflater.from(getContext()).inflate(R.layout.grid_view_layout, parent, false);
        }

        if(productList.size() > 0) {
            Product product = productList.get(position);
            TextView txtProductId = (TextView) listitemView.findViewById(R.id.lblProductId);
            TextView txtProductName = (TextView) listitemView.findViewById(R.id.lblProductName);
            TextView txtProductQty = (TextView) listitemView.findViewById(R.id.lblQuantity);

            txtProductId.setText(String.valueOf(product.getProductId()));
            txtProductName.setText(product.getProductName());
            txtProductQty.setText(String.valueOf(product.getQuantity()));

            ImageView upImage = listitemView.findViewById(R.id.imgUpdate);
            upImage.setImageResource(R.drawable.edit);
        }

        return listitemView;
    }

}
