package com.project.two.riyamkasim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    // Database handler
    private InventoryDatabase inventoryDatabase;

    // Inputs
    private EditText txtUsername;
    private EditText txtPassword;
    private EditText txtFirstName;
    private EditText txtLastName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Create database handler
        this.inventoryDatabase = InventoryDatabase.getInstance(this);

        // set references
        this.txtUsername = findViewById(R.id.txtRegisterUserName);
        this.txtPassword = findViewById(R.id.txtRegisterPassword);
        this.txtFirstName = findViewById(R.id.txtFirstName);
        this.txtLastName = findViewById(R.id.txtLastName);
    }

    /**
     * Function to main Login Screen.
     *
     * @param view
     */
    public void doBack(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    /**
     * Function to move to the Registration Screen
     *
     * @param view
     */
    public void doRegister(View view) {

        // Parse input data
        String username = this.txtUsername.getText().toString();
        String password = this.txtPassword.getText().toString();
        String firstName = this.txtFirstName.getText().toString();
        String lastName = this.txtLastName.getText().toString();

        // Create Member object
        Member member = new Member();
        member.setFirstName(firstName);
        member.setLastName(lastName);
        member.setUsername(username);
        member.setPassword(password);

        // Check if Username already taken
        Member current = this.inventoryDatabase.inventoryDao().getMember(username);

        if(current != null) { // already exist
            Toast.makeText(this, "Username already taken - try again", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create user
        this.inventoryDatabase.inventoryDao().insertMember(member);

        // clear inputs
        this.txtUsername.setText("");
        this.txtLastName.setText("");
        this.txtPassword.setText("");
        this.txtFirstName.setText("");

        // notify user
        Toast.makeText(this, "Registration Successful - Go back to Login", Toast.LENGTH_SHORT).show();
    }

}