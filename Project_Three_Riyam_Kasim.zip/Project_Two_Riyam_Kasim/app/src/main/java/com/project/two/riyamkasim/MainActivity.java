package com.project.two.riyamkasim;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Database handler
    private InventoryDatabase inventoryDatabase;

    // Input components
    private EditText txtUsername;
    private EditText txtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Create database handler
        this.inventoryDatabase = InventoryDatabase.getInstance(this);

        // set references
        this.txtUsername = findViewById(R.id.txtLoginUserName);
        this.txtPassword = findViewById(R.id.txtLoginPassword);
    }

    /**
     * Function to close the application.
     *
     * @param view
     */
    public void doClose(View view) {
        finish();
        System.exit(0);
    }

    /**
     * Function to login the user
     *
     * @param view
     */
    public void doLogin(View view) {

        // Parse values
        String username = this.txtUsername.getText().toString();
        String password = this.txtPassword.getText().toString();

        // Get Member from database for the given username
        Member member = this.inventoryDatabase.inventoryDao().getMember(username);

        // if null, its not authenticated
        if(member == null) {
            Toast.makeText(this, "Username you entered doesn't exist",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Check for password match
        if(!member.getPassword().equals(password)) {
            Toast.makeText(this, "Password doesn't match", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();

        // Login Successful
        // move to Inventory grid
        Intent intent = new Intent(this, Inventory.class);
        startActivity(intent);
    }

    /**
     * Function to move to the Registration Screen
     *
     * @param view
     */
    public void doRegister(View view) {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
}