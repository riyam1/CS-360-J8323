package com.project.two.riyamkasim;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Inventory extends AppCompatActivity {

    // Grid View
    private GridView gridViewProducts;

    // backend list
    private List<Product> productList;

    // Database
    private InventoryDatabase inventoryDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // database handler
        this.inventoryDatabase = InventoryDatabase.getInstance(this);

        // bind gridview
        //ArrayList<Product> productList = new ArrayList<Product>();
        //productList.add(new Product(1001, "Mobile Phone", 10));
        //productList.add(new Product(1002, "TV", 10));
        //productList.add(new Product(1003, "Laptop", 10));
        this.productList = this.inventoryDatabase.inventoryDao().getAllProducts();

        this.gridViewProducts = findViewById(R.id.gridViewProducts);
        ProductAdapter adapter= new ProductAdapter(this, productList);
        gridViewProducts.setAdapter(adapter);

        this.gridViewProducts.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position,
                                    long arg3) {
                    Intent intent = new Intent(Inventory.this, UpdateActivity.class);
                    intent.putExtra("id", productList.get(position).getProductId());
                    startActivity(intent);
            }
        });
    }

    public void doAdd(View view) {
        Intent intent = new Intent(this, AddProductActivity.class);
        startActivity(intent);
    }

    public void doLogout(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void setPermissions(View view) {
        if(!checkSMSPermission(Manifest.permission.SEND_SMS)) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        }
    }

    private boolean checkSMSPermission(String sendSms) {
        return ContextCompat.checkSelfPermission(this,sendSms) == PackageManager.PERMISSION_GRANTED;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        String phoneNo = "+12021231234"; // update this number to send message

        if (grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();

            List<Product> list = inventoryDatabase.inventoryDao().getAllProducts();
            String message = "Zero Quantity Products\n";
            for(Product p: list) {
                if(p.getQuantity() == 0) {
                    message += p.getProductName() + " quantity: 0\n";
                }
            }

            smsManager.sendTextMessage(phoneNo, null, message, null, null);
            Toast.makeText(getApplicationContext(), "Inventory Alert sent to Number: " + phoneNo,
                    Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getApplicationContext(),
                    "Permission is not granted to send SMS Alert", Toast.LENGTH_LONG).show();
            return;
        }

    }
}