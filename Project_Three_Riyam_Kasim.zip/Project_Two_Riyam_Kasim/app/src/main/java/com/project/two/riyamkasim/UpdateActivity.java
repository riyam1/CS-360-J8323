package com.project.two.riyamkasim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {

    // Inputs
    private EditText txtProductId;
    private EditText txtProductName;
    private EditText txtQuantity;

    // Database
    private InventoryDatabase inventoryDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        // database handler
        // database instance
        this.inventoryDatabase = InventoryDatabase.getInstance(this);

        // set references
        this.txtProductId = findViewById(R.id.txtUProductId);
        this.txtProductName = findViewById(R.id.txtUProductName);
        this.txtQuantity = findViewById(R.id.txtUQuantity);

        // Get the Product
        Intent intent = this.getIntent();
        int id = intent.getIntExtra("id", 0);
        Product product = this.inventoryDatabase.inventoryDao().getProduct(id);

        // populate values
        this.txtProductId.setText(String.valueOf(id));
        this.txtProductName.setText(product.getProductName());
        this.txtQuantity.setText(String.valueOf(product.getQuantity()));

        // disable product id
        this.txtProductId.setKeyListener(null);
        this.txtProductId.setEnabled(false);
    }

    /**
     * Function to add new product
     *
     * @param view
     */
    public void doUpdateProduct(View view) {

        try {

            // parse values
            String productName = this.txtProductName.getText().toString();
            int quantity = Integer.parseInt(this.txtQuantity.getText().toString());
            int id = Integer.parseInt(this.txtProductId.getText().toString());

            if (productName.length() <= 0) {
                Toast.makeText(this, "Please provide product name", Toast.LENGTH_SHORT).show();
                return;
            }

            Product product = new Product();
            product.setProductName(productName);
            product.setQuantity(quantity);
            product.setProductId(id);

            // insert product
            this.inventoryDatabase.inventoryDao().updateProduct(product);
            Toast.makeText(this, "Product has been updated", Toast.LENGTH_SHORT).show();

        } catch(Exception e) {
            Toast.makeText(this, "Something Wrong Happened", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Delete the product
     *
     * @param view
     */
    public void doDeleteProduct(View view) {
        try {

            // parse values
            String productName = this.txtProductName.getText().toString();
            int quantity = Integer.parseInt(this.txtQuantity.getText().toString());
            int id = Integer.parseInt(this.txtProductId.getText().toString());

            if (productName.length() <= 0) {
                Toast.makeText(this, "Please provide product name", Toast.LENGTH_SHORT).show();
                return;
            }

            Product product = new Product();
            product.setProductName(productName);
            product.setQuantity(quantity);
            product.setProductId(id);

            // insert product
            this.inventoryDatabase.inventoryDao().deleteProduct(product);
            int count = this.inventoryDatabase.inventoryDao().getAllProducts().size();
            Toast.makeText(this, "Product has been deleted - " + count, Toast.LENGTH_SHORT).show();

            this.txtQuantity.setText("");
            this.txtProductId.setText("");
            this.txtProductName.setText("");

        } catch(Exception e) {
            Toast.makeText(this, "Something Wrong Happened", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Go back to the Inventory grid
     *
     * @param view
     */
    public void doBack(View view) {
        Intent intent = new Intent(this, Inventory.class);
        startActivity(intent);
    }
}