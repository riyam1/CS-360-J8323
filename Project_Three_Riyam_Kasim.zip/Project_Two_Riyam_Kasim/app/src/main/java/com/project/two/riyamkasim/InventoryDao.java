package com.project.two.riyamkasim;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public abstract class InventoryDao {

    /**
     * Get all the Products
     *
     * @return list of Products
     */
    @Query("SELECT * FROM Product")
    public abstract List<Product> getAllProducts();

    /**
     * Get a Particular Product that matches the given Product Id
     *
     * @param productId id to match
     * @return return product
     */
    @Query("SELECT * FROM Product WHERE productId=:productId")
    public abstract Product getProduct(int productId);

    /**
     * Insert new Product into the database
     *
     * @param product to insert
     */
    @Insert
    public abstract void insertProduct(Product product);

    /**
     * Delete a product passed to this function
     *
     * @param product to delete
     */
    @Delete
    public abstract void deleteProduct(Product product);

    /**
     * Update a Product inside database to the product passed as parameter
     *
     * @param product to update
     */
    @Update
    public abstract void updateProduct(Product product);

    /**
     * Get all the registered members of this application.
     *
     * @return list of members
     */
    @Query ("SELECT * FROM Member")
    public abstract  List<Member> getAllMembers();

    /**
     * Insert new member for new registration.
     *
     * @param member to insert
     */
    @Insert
    public abstract void insertMember(Member member);

    /**
     * Delete a registered member to remove his/her authentication role
     *
     * @param member to delete
     */
    @Delete
    public abstract void deleteMember(Member member);

    /**
     * Update a Member's data
     *
     * @param member to update
     */
    @Update
    public abstract void updateMember(Member member);

    /**
     * Get a Particular Member from the database whose username matches the
     * parameter value.
     *
     * @param username to match
     * @return return Member
     */
    @Query("SELECT * FROM Member WHERE username=:username")
    public abstract Member getMember(String username);
}
